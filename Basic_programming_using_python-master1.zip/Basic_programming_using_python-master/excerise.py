from pylab import *
from pylab import plot
time = [0.,1.,2,3]
distance = [7.,11,15,19]
plot(time,distance)
xlabel('time')
ylabel('distance')
show()

clf()
plot(time,distance,'o')

clf()
plot(time,distance,'.')
mtlist= []
p = [2,3,5,7]
p[1]
s=p[0]+p[1]+p[-1]
print(p[1])
print(s)
p[1:3]
print(p)
