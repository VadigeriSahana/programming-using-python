
print("hello",end=' ')
print("world")