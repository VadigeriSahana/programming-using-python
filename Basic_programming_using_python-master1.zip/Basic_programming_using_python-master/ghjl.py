a=input()
x=list(a)
print(x)
(x.sort())
print(x)




a['a']=2
a['b']=3