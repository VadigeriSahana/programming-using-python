from numpy import linspace
n=int(input())
data=linspace(1,2,n)
for x in data:
    print(x)

    
i=4        
while i>0:
        
    n=input()
    l=[]
    l.append(n)
    i=i-1
print(l,end=',')