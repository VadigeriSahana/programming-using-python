def largest(a):
    data=[]
    for line in a:
         data.append(float(line))
    return data