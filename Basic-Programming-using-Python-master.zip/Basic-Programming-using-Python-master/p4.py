week=['mon','tue','wed','thu','fri','sat','sun]
s='Sunday'
s.lower()[:3] in week